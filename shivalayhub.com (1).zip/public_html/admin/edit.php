
          
          
<?php
include "connection.php"; // Ensure the connection to the database is included
$id = "";
$title = "";
$charge = "";
$size = "";
$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == 'GET') {
    if (!isset($_GET['id'])) {
        header("location: room.php");
        exit;
    }
    $id = $_GET['id'];
    $sql = "SELECT * FROM delux WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id); // Use "i" for integer binding
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (!$row) {
        header("location: room.php");
        exit;
    }

    $title = $row["title"];
    $charge = $row["charge"];
    $size = $row["size"];
} elseif ($_SERVER["REQUEST_METHOD"] == 'POST') {
    $id = $_POST["id"];
    $title = $_POST["title"];
    $charge = $_POST["charge"];
    $size = $_POST["size"];
    
    // File upload handling
    $target_dir = "../img/";

    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true); // Create directory if it does not exist
    }

    // Sanitize the file name to avoid issues
    $filename = basename($_FILES["fileToUpload"]["name"]);
    $target_file = $target_dir . $filename;

    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'zip', 'avif'];

    // Check file extension
    if (!in_array($imageFileType, $allowedExtensions)) {
        $error = "Sorry, only JPG, JPEG, PNG, AVIF, GIF, PDF, DOC, and ZIP files are allowed.";
        $uploadOk = 0;
    }

    // Check if there was an error uploading
    if ($uploadOk == 0) {
        $error = "Sorry, your file was not uploaded.";
    } else {
        // Try to upload the file
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            $success = "The file " . $filename . " has been uploaded.";
        } else {
            $error = "Sorry, there was an error uploading your file.";
        }
    }

    // Proceed with database update if no errors with file upload
    if ($uploadOk == 1) {
        // Prepare the update statement
        $sql = "UPDATE delux SET title = ?, charge = ?, size = ?, target_file = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $title, $charge, $size, $filename, $id); // Bind parameters

        if ($stmt->execute()) {
            $success = "Record updated successfully!";
            header("location: room.php");
            exit;
        } else {
            $error = "Error updating record: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shivalay</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    
    <!-- Bootstrap CSS -->
   
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
     
</head>
<body>
                        <!-- Header Start -->
          <?php include_once 'header.php';?>
          <!-- Header End -->

    <div class="col-lg-6 m-auto">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form action="#" method="post" enctype="multipart/form-data">
            <br><br>
            <div class="card">
                <div class="card-header bg-warning">
                    <h1 class="text-white text-center">Update Member</h1>
                </div><br>

                <input type="hidden" name="id" value="<?php echo $id; ?>" class="form-control" required> <br>

                <label>Title:</label>
                <input type="text" name="title" required value="<?php echo htmlspecialchars($title); ?>" class="form-control"> <br>

                <label>Charge For Normal Days:</label>
                <input type="text" name="charge" required value="<?php echo htmlspecialchars($charge); ?>" class="form-control"> <br>

                <label>Room Size:</label>
                <input type="text" name="size" required value="<?php echo htmlspecialchars($size); ?>" class="form-control"> <br>

                <label for="fileUpload">Choose an image or file:</label>
                <input type="file" name="fileToUpload" required id="fileToUpload" class="form-control"> <br>

                <button class="btn btn-success" type="submit" name="submit">Edit</button><br>
                <a class="btn btn-info" href="room.php">Close</a><br>
            </div>
        </form>
    </div>
</body>
</html>
