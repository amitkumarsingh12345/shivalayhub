<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- Bootstrap CSS -->
   
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <title>Shivalay</title>
  </head>
  <body>
                        <!-- Header Start -->
          <?php include_once 'header.php';?>
          <!-- Header End -->
    
    <div class="container my-4">
         <ul class="navbar-nav">
           
            <li class="nav-item">
              <a type="button" class="btn btn-primary text-white nav-link active d-inline px-2" href="create.php">New +</a>
            </li>
          </ul>
    <table class="table d-none d-md-table">
    <thead>
      <tr>
        <th>Sr.No</th>
        <th>Title</th>
        <th>Charge For Normal Days</th>
        <th>Room Size</th>
        <th>ACTIONS</th>
      </tr>
    </thead>
    <tbody>
      <?php
        include "connection.php";

        if(!isset($_COOKIE["user_email"])) {
           header("Location: /admin/login.php");
        }
         
        $i=0;
        $sql = "select * from delux";
        $result = $conn->query($sql);
        if(!$result){
          die("Invalid query!");
        }
        while($row=$result->fetch_assoc()){
            $i = $i+1;
          echo "
      <tr>
        <th>$i</th>
        <td>$row[title]</td>
        <td>$row[charge]</td>
        <td>$row[size]</td>
        <td>
                  <a class='btn btn-success' href='edit.php?id=$row[id]'>Edit</a>
                  <a class='btn btn-danger' href='delete.php?id=$row[id]'>Delete</a>
                </td>
      </tr>
      ";
        }
      ?>
    </tbody>
  </table>
  
  
   <?php
        include "connection.php";

        if(!isset($_COOKIE["user_email"])) {
           header("Location: /admin/login.php");
        }
         
        $i=0;
        $sql = "select * from delux";
        $result = $conn->query($sql);
        if(!$result){
          die("Invalid query!");
        }
        while($row=$result->fetch_assoc()){
            $i = $i+1;
         echo "
  <div class='card text-bg-light ms-auto my-3 w-100 d-inline-block d-md-none' style='max-width: 18rem;'>
    <div class='card-header'>" . $row['title'] . "</div>
    <div class='card-body'>
      <h5 class='card-title'>Room Size: " . $row['size'] . "</h5>
      <p class='card-text'>" . $row['charge'] . "</p>
    </div><br/>
     <a class='btn btn-success' href='edit.php?id=$row[id]'>Edit</a>
                  <a class='btn btn-danger' href='delete.php?id=$row[id]'>Delete</a>
  </div>";


        }
      ?>
  
  
  
      </div>
    
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>