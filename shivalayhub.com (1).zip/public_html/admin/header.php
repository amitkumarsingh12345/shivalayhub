 <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="index.php">Shivalay Admin Panel</a>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/admin/index.php">Customers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link"href="/admin/room.php">Rooms</a>
        </li>
          <li class="nav-item">
              <form action='#' method='post'>
                  <input type="submit" class="nav-link active" name="logout" id="logout" value="Logout">
              </form>
              
              <?php
                 if(isset($_POST['logout'])) {
                     setcookie("user", "", time() - 3600, "/");
                     header("Location: ../index.php");
                 }
              ?>
              
            </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>