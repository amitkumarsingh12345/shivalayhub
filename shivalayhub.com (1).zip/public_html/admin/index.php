<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
   
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <title>Shivalay</title>
  </head>
  <body>
    
    
    
    
    
                         <!-- Header Start -->
          <?php include_once 'header.php';?>
          <!-- Header End -->
    
    
    
    
    
    
    <div class="container my-4">
        
        <h4 class="text-center">All Customers</h4>
       
    <table class="table d-none d-md-table">
    <thead>
      <tr>
        <th>Sr.No</th>
        <th>Name</th>
        <th>Email</th>
        <th>Start Date</th>
        <th>End Date</th>
         <th>Phone</th>
        <th>Subject</th>
        <th>Message</th>
      </tr>
    </thead>
    <tbody>
      <?php
        include "connection.php";

        if(!isset($_COOKIE["user_email"])) {
           header("Location: /admin/login.php");
        }
         
        $i=0;
        $sql = "select * from customer";
        $result = $conn->query($sql);
        if(!$result){
          die("Invalid query!");
        }
        while($row=$result->fetch_assoc()){
            $i = $i+1;
          echo "
      <tr>
        <th>$i</th>
        <td>$row[name]</td>
        <td>$row[email]</td>
        <td>$row[start]</td>
         <td>$row[end]</td>
        <td>$row[phone]</td>
        <td>$row[subject]</td>
        <td>$row[message]</td>
      </tr>
      ";
        }
      ?>
    </tbody>
  </table>
  
  
   <?php
        include "connection.php";

        if(!isset($_COOKIE["user_email"])) {
           header("Location: /admin/login.php");
        }
         
        $i=0;
        $sql = "select * from customer";
        $result = $conn->query($sql);
        if(!$result){
          die("Invalid query!");
        }
        while($row=$result->fetch_assoc()){
            $i = $i+1;
         echo "
  <div class='card text-bg-light ms-auto my-3 w-100 d-inline-block d-md-none' style='max-width: 18rem;'>
    <h4 class='text-center'>All Customers</h4>
    <div class='card-header'><b>" . $i . "</b></div>
    <div class='card-body'>
    <h5>Customer Name</h5>
      <p class='card-text'>" . $row['name'] . "</p>
      <br/>
      
       <h5>Email</h5>
      <p class='card-text'>" . $row['email'] . "</p>
      <br/>
      
       <h5>Start Date & Time</h5>
      <p class='card-text'>" . $row['start'] . "</p>
      <br/>
      
       <h5>End Date & Time</h5>
      <p class='card-text'>" . $row['end'] . "</p>
      <br/>
      
       <h5>Phone</h5>
      <p class='card-text'>" . $row['phone'] . "</p>
      <br/>
      
       <h5>Subject</h5>
      <p class='card-text'>" . $row['subject'] . "</p>
      <br/>
      
       <h5>Message</h5>
      <p class='card-text'>" . $row['message'] . "</p>
      <br/>
      
    </div>
  </div>";


        }
      ?>
  
  
  
      </div>
    
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>