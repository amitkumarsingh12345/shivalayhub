<?php 
    $servername = "localhost";
    $username = "u440643745_shivalay_user";
    $password = "Amit@123#123";
    $db_name = "u440643745_shivalay";  
    $conn = new mysqli($servername, $username, $password, $db_name);
    if($conn->connect_error){
        die("Connection failed".$conn->connect_error);
    }
    echo "";
    
    ?>