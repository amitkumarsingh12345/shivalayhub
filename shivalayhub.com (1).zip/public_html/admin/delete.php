<?php
    include "connection.php";
    
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $sql = "DELETE from `delux` where id=$id";
        $conn->query($sql);
    }
    header('location:/admin/room.php');
    exit;
?>