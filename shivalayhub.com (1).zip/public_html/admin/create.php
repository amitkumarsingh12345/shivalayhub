<!DOCTYPE html>
<html>
<head>
 <title>Shivalay</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>
    
                     <!-- Header Start -->
          <?php include_once 'header.php';?>
          <!-- Header End -->
          
 <div class="col-lg-6 m-auto">
 
 <form action="#" method="post" enctype="multipart/form-data">
 
 <br><br><div class="card">
 
 <div class="card-header bg-primary">
 <h1 class="text-white text-center">  Create New Delux </h1>
 </div><br>

 <label> Title </label>
 <input type="text" name="title" class="form-control" required> <br>

 <label> Charge For Normal Days </label>
 <input type="text" name="charge" class="form-control" required> <br>

 <label> Room Size </label>
 <input type="text" name="size" class="form-control" required> <br>
 
  <label for="fileUpload">Choose an image or file:</label>
        <input type="file" name="fileToUpload" id="fileToUpload" class="form-control" required>

 <button class="btn btn-success" type="submit" name="submit"> Add
 </button><br>
 <a class="btn btn-info" type="submit" name="cancel" href="room.php"> Close </a><br>

 </div>
 </form>
 </div>
</body>
</html>


<?php
    include 'connection.php';
    
    if(isset($_POST['submit'])){
        
    $target_dir = "../img";
    
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

$filename = basename($_FILES["fileToUpload"]["name"]);    
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    
    $uploadOk = 1;
    
    if (isset($_POST["submit"])) {
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'zip', 'avif']; 
        
        if (!in_array($imageFileType, $allowedExtensions)) {
            echo "Sorry, only JPG, JPEG, PNG, AVIF, GIF, PDF, DOC, and ZIP files are allowed.";
            $uploadOk = 0;
        }
    }
  
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "The file " . basename($_FILES["fileToUpload"]["name"]) . " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
        
        $title = $_POST['title'];
        $charge = $_POST['charge'];
        $size = $_POST['size'];
        
        
        $q = " INSERT INTO `delux`(`title`, `charge`, `size`, `target_file`) VALUES ( '$title', '$charge', '$size', '$filename' )";

        $query = mysqli_query($conn,$q);
        header("location: room.php");
    }
?>