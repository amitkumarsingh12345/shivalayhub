 <!-- Reservation Start -->
        <div class="container-xxl py-5 px-0 wow fadeInUp" data-wow-delay="0.1s">
            <div class="row g-0">
                <div class="col-md-6 bg-dark">
                    <div class="video">
                        
                        <div class="video d-flex justify-content-center align-item-center">
                        <img src="img/qrcode.jpeg" class="img-fluid m-auto" alt="...">
                        
                        <!--<button type="button" class="btn-play" data-bs-toggle="modal"-->
                        <!--    data-src="img/video1.mp4" data-bs-target="#videoModal">-->
                        <!--    <span></span>-->
                        <!--</button>-->
                    </div>
                    </div>
                </div>
                <div class="col-md-6 bg-dark d-flex align-items-center">
                    <div class="p-5 wow fadeInUp" data-wow-delay="0.2s">
                        <h5 class="section-title ff-secondary text-start text-primary fw-normal">Reservation</h5>
                        <h1 class="text-white mb-4">Book Online</h1>
                        
                         <p>
                             <a href="https://www.makemytrip.com/" target="_blank">
                                 <img src="img/makemytrip.png" class="rounded m-1" style="height:50px;width:50px" alt="..." title="MakeMyTrip">
                             </a>
                             
                             <a href="https://www.goibibo.com/?utm_source=google&utm_medium=cpc&utm_campaign=DF-Brand-EM&utm_adgroup=Only%20Goibibo&utm_term=!SEM!DF!G!Brand!RSA!108599293!6504095653!602838584772!e!goibibo!m!&gad_source=1&gclid=Cj0KCQiAst67BhCEARIsAKKdWOldITIT4SplZS5J3A3_IluT4gjgIlU8jLI1-WUcuy9UfCh_c5EFIjsaAq13EALw_wcB" target="_blank">
                                  <img src="img/goibibo.png" class="rounded m-1" style="height:50px;width:50px" alt="..." title="Goibibo">
                                  </a>
                                  
                            <a href="https://www.booking.com/index.en-gb.php?aid=355028&sid=6c7ac04c518fb688ba8056ed4e612aa9&keep_landing=1&sb_price_type=total&auth_success=1&account_created=1" target="_blank">
                                <img src="img/booking.png" class="rounded m-1" style="height:50px;width:50px" alt="..." title="Booking.com">
                                 </a>
                                 
                                 <a href="https://inigo.com/sales-list/the-cottage" target="_blank">
                                     <img src="img/cottage.png" class="rounded m-1" style="height:50px;width:50px" alt="..." title="the-cottage">     
                                 </a>
                                 
                                 <a href="https://www.cleartrip.com/" target="_blank">
                                     <img src="img/clear.png" class="rounded m-1" style="height:50px;width:50px" alt="..." title="clear-trip">
                                 </a>
                        </p>
                        
                        <hr/> <p class="text-center">or</p>
                        
                        <form action="send_mail.php" method="post">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                                        <label for="name">Your Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
                                        <label for="email">Your Email</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="phone" name="phone" placeholder="Your Phone" required>
                                        <label for="email">Phone</label>
                                    </div>
                                </div>
                                
                                
                                
                                <div class="col-md-6">
                                     <div class="form-floating">
                                
<select class="form-select" id="subject" name="subject">
      <option value="Delux" selected>Choose Option</option>
  <option value="Delux">Delux</option>
  <option value="Super Delux">Super Delux</option>
  <option value="Delux with shahi snan">Delux shahi snan</option>
   <option value="Delux with shahi snan">Delux with shahi snan</option>
</select>
</div>
</div>

                                
                                <!--   <div class="col-md-6">     -->
                                <!--    <div class="form-floating">-->
                                <!--        <input type="text" class="form-control" id="subject" name="subject" placeholder="Your Subject" required>-->
                                <!--        <label for="email">Subject</label>-->
                                <!--    </div>-->
                                <!--</div>-->
                                
                                 <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="date" class="form-control" id="start" name="start" placeholder="Start Date & Time" required>
                                        <label for="start">Start Date & Time</label>
                                    </div>
                                </div>
                            
                                
                                 <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="date" class="form-control" id="end" name="end" placeholder="End Date & Time" required>
                                        <label for="end">End Date & Time</label>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Special Request" id="message" name="message"
                                            style="height: 100px" required></textarea>
                                        <label for="message">Message</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary w-100 py-3" type="submit">Book Now</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="videoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Youtube Video</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- 16:9 aspect ratio -->
                        <div class="ratio ratio-16x9">
                            <iframe class="embed-responsive-item" src="" id="video" allowfullscreen
                                allowscriptaccess="always" allow="autoplay"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Reservation Start -->
        

