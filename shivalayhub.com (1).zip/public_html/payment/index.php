<!DOCTYPE html>
<html>
<head>
    <title>Stripe Example</title>
    <meta charset="UTF-8" />
</head>
<body>

    <h1>Stripe Example</h1>
    <form method="post" action="checkout.php">
        <p>T-shirt</p>
        <p><strong>US$20.00</strong></p>
        <button>Pay</button>
    </form>
</body>
</html>